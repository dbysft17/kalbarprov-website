function openPopupMasukan() {
    document.getElementById("divOne").style.visibility = "visible";
    document.getElementById("divOne").style.opacity = "1";
}

function closePopupMasukan() {
    document.getElementById("divOne").style.visibility = "hidden";
    document.getElementById("divOne").style.opacity = "0";
}
