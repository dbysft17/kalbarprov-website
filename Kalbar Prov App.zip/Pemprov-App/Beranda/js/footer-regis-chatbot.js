function openPopupRegisChatbot() {
    document.getElementById("divTwo").style.visibility = "visible";
    document.getElementById("divTwo").style.opacity = "1";
}

function closePopupRegisChatbot() {
    document.getElementById("divTwo").style.visibility = "hidden";
    document.getElementById("divTwo").style.opacity = "0";
}
