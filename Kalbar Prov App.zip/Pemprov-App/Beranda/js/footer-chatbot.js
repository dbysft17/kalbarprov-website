function openPopupChatbot() {
    document.getElementById("divThree").style.visibility = "visible";
    document.getElementById("divThree").style.opacity = "1";
}

function closePopupChatbot() {
    document.getElementById("divThree").style.visibility = "hidden";
    document.getElementById("divThree").style.opacity = "0";
}
